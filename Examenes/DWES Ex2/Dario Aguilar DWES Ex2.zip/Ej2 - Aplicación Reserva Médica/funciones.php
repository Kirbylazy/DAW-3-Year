<?php
include_once('parametros.php');
session_start();
// Función de conexión a la base de datos
function conectarBD() {

        try {
        // Crear la conexión PDO
        $conexion = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4", DB_USER, DB_PASS);
        $conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // Establecer manejo de errores
        } catch (PDOException $e) {
            echo "Error de conexión: " . $e->getMessage();
            exit();
        }

    return $conexion;
   
}

function desconectar(&$conex) {

    $conex = null;
    
}

// Función para registrar un nuevo paciente
function registrarPaciente($nombre, $email, $clave): bool
{
        $pdo = conectarBD();
        // Comprobar si el email ya existe
        $stmt = $pdo->prepare("SELECT id FROM pacientes WHERE email = :email");
        $stmt->execute(['email' => $email]);
        $existe = $stmt->fetch(PDO::FETCH_ASSOC);
    
        if (!empty($existe)) {
            return false;
        }
    
        // Cifrar contraseña
        $hash = password_hash($clave, PASSWORD_DEFAULT);
    
        // Insertar el nuevo paciente
        $stmt = $pdo->prepare("INSERT INTO pacientes (nombre, email, clave) 
                                    VALUES (:nombre, :email, :clave)");
        $stmt->bindParam(':nombre', $nombre, PDO::PARAM_STR);
        $stmt->bindParam(':email', $email, PDO::PARAM_STR);
        $stmt->bindParam(':clave', $hash, PDO::PARAM_STR);
        $stmt->execute();
    
        desconectar($pdo);
    
        return true;
    }

// Iniciar sesión del paciente
function iniciarSesion($email, $clave): bool
{
        $pdo = conectarBD();
    
        $stmt = $pdo->prepare("SELECT * FROM pacientes WHERE email = :email");
        $stmt->execute(['email' => $email]);
        $paciente = $stmt->fetch(PDO::FETCH_ASSOC);
    
        if (!empty($paciente)) {
    
            if (password_verify($clave, $paciente['clave'])) {

                // Guardar datos en la sesión
                $_SESSION['id'] = $paciente['id'];
                $_SESSION['nombre'] = $paciente['nombre'];

                $_SESSION['mensaje'] = "Sesion inciada correctamente";
                return true;
    
            } else {

                $_SESSION['mensaje'] = "Clave incorrecta";
                return false;
    
            }
        } else {
    
            $_SESSION['mensaje'] = "Paciente no registrado";
            return false;
            
        }
    }

// Función para comprobar si un médico está disponible
function comprobarDisponibilidad($medico_id, $fecha): bool
{
        $pdo = conectarBD();
    
        $sql = "SELECT * FROM citas WHERE medico_id = :medico_id AND fecha = :fecha AND activa = TRUE";
        $stmt = $pdo->prepare($sql);
        $stmt->execute(['medico_id' => $medico_id, 
                        'fecha' => $fecha]);
        $medico = $stmt->fetch(PDO::FETCH_ASSOC);
    
        if (!empty($medico)) {
            // Si hay resultados, significa que el médico ya está ocupado
            $_SESSION['mensaje'] = "El medico está ocupado";
            return false;
    
        } else {
            $_SESSION['mensaje'] = "El medico está disponible";
            return true;
        }
    
}

// Crear nueva cita
function crearCita($paciente_id, $medico_id, $fecha, $motivo): bool
{
        $pdo = conectarBD();

        // Comprobar disponibilidad, usando la función anterior
        if (comprobarDisponibilidad($medico_id, $fecha)) {

            // Si el médico está disponible, hago la cita
            $stmt = $pdo->prepare("INSERT INTO citas (paciente_id, medico_id, fecha, motivo) 
                                    VALUES (:paciente_id, :medico_id, :fecha, :motivo)");
            $stmt->execute([
                'paciente_id' => $paciente_id,
                'medico_id' => $medico_id,
                'fecha' => $fecha,
                'motivo' => $motivo
            ]);

            $_SESSION['mensaje'] = "Cita creada correctamente";
            return true;
    
        } else {

            $_SESSION['mensaje'] = "El médico no está disponible en esa fecha";
            return false;
        }
    }

// Cancelar cita
function cancelarCita($cita_id, $paciente_id): bool
{
    $pdo = conectarBD();

    $stmt = $pdo->prepare("DELETE FROM citas WHERE id = :cita_id 
                            AND paciente_id = :paciente_id");
    $stmt->execute([
        'cita_id' => $cita_id,
        'paciente_id' => $paciente_id
    ]);
    if($stmt->rowCount() > 0){
        $_SESSION['mensaje'] = "Error al cancelar la cita";
        return false;
    }else{
        $_SESSION['mensaje'] = "Cita cancelada correctamente";
        return true;
    }

}

// Obtener citas del paciente actual
function obtenerCitas($paciente_id)
{
    $pdo = conectarBD();
    $stmt = $pdo->prepare("SELECT c.*, m.nombre as medico_nombre, m.especialidad, m.consulta 
                            FROM citas c JOIN medicos m ON c.medico_id = m.id WHERE c.paciente_id = :paciente_id 
                            ORDER BY c.fecha DESC");
    $stmt->execute(['paciente_id' => $paciente_id]);
    $citas = $stmt->fetchAll(PDO::FETCH_ASSOC);

    return $citas;

}

// OBTENER MÉDICOS DISPONIBLES
function obtenerMedicos()
{
    $pdo = conectarBD();
    $stmt = $pdo->prepare("SELECT * FROM medicos ORDER BY nombre");
    $stmt->execute();
    $medicos = $stmt->fetchAll(PDO::FETCH_ASSOC);

    return $medicos;
}

// Cambiar estado de cita (de programada a atendida)
function cambiarEstadoCita($cita_id, $paciente_id)
{
    $pdo = conectarBD();
    // Obtener estado actual
    $stmt = $pdo->prepare("SELECT activa FROM citas WHERE id = :cita_id AND paciente_id = :paciente_id");
    $stmt->execute(['cita_id' => $cita_id, 'paciente_id' => $paciente_id]);
    $cita = $stmt->fetch(PDO::FETCH_ASSOC);

    if (empty($cita)) {

        $_SESSION['mensaje'] = "La cita no existe";
        return false;

    }

    $estado = $cita['activa'];
    
    if ($estado == 1) {

        // Actualizar desde programada (activa = 1), a atendida (activa = 0)
        $stmt = $pdo->prepare("UPDATE citas SET activa = 0 WHERE id = :cita_id AND paciente_id = :paciente_id");
        $stmt->execute(['cita_id' => $cita_id, 'paciente_id' => $paciente_id]);

        $_SESSION['mensaje'] = "Cita actualizada correctamente";
        return true;

    } elseif ($estado == 0) {

        $_SESSION['mensaje'] = "Error al cambiar el estado de la cita";
        return false;
    }

}
