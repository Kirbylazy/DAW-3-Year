<?php
include_once('funciones.php');
// Verificar que el usuario esté autenticado o se vuelva a index
if(!isset($_SESSION['id'])){

    header('Location: index.php');
    exit;
}

// Procesamiento de acciones POST
if($_SERVER['REQUEST_METHOD'] == 'POST'){

    // Cerrar sesión
    if(isset($_POST['logout'])){

        $_SESSION =  [];
        session_destroy();
        header('Location: index.php');
        exit;

    }


    // Crear nueva cita
    if(isset($_POST['crear_cita'])){

        if(crearCita($_SSESION['id'], $_POST['medico_id'], $_POST['fecha'], $_POST['motivo'])){

            $mensaje = 'La cita ha sido crada correctamente';
        }else{
            $mensaje = 'No se ha podido crear la cita';
        }
    }

    // Cancelar cita
    if(isset($_POST['cancelar'])){

        $cita_id = $_POST['eliminar'];
        cancelarCita($cita_id, $_SESSION['id']);
    }


    // Cambiar estado de cita
    if(isset($_POST['cambiar_estado'])){

        $cita_id = $_POST['cambiar_estado'];
        cancelarCita($cita_id, $_SESSION['id']);
    }


// Obtener médicos para el select list

$medicos = obtenerMedicos();


// Obtener citas, para mostrar en la tabla

$citas = obtenerCitas($_SESSION['id']);

}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Sistema de Gestión de Citas Médicas</title>
    <link rel="stylesheet" type="text/css" href="estilos.css">
</head>

<body>
    <table>
        <tr>
            <th colspan="2">Sistema de Gestión de Citas Médicas</th>
        </tr>
        <tr>
            <td colspan="2">
                Bienvenido, <?= $_SESSION['nombre'] ?>
                <form method="post" action="">
                    <input type="submit" name="logout" value="Cerrar sesión">
                </form>
            </td>
        </tr>
    </table>

    <!-- MENSAJES INFORMATIVOS -->
    <?php if(!empty($_SESSION['mensaje'])): ?>
        <table class="mensaje">
            <tr>
                <td><?php $_SESSION['mensaje'] ?></td>
            </tr>
        </table>
    <?php endif; ?>

    <!-- Formulario para crear cita -->
    <form method="post" action="">
        <table>
            <tr>
                <th colspan="2">Nueva Cita</th>
            </tr>
            <tr>
                <td><label for="medico_id">Médico:</label></td>
                <td>
                    <select id="medico_id" name="medico_id" required>
                        <option value="">Seleccione un médico</option>
                                <?php foreach ($medicos as $m): ?>
                        <option value="<?= $m['id'] ?>">
                            <?= $m['nombre'] ?>
                        </option>
                    <?php endforeach; ?>
                    </select>
                </td>
            </tr>
            <tr>
                <td><label for="fecha">Fecha:</label></td>
                <td>
                    <input type="date" id="fecha" name="fecha" value="<?php echo date('Y-m-d'); ?>">
                </td>
            </tr>
            <tr>
                <td><label for="motivo">Motivo:</label></td>
                <td>
                    <textarea id="motivo" name="motivo" required></textarea>
                </td>
            </tr>
            <tr>
                <td colspan="2">
                    <input type="submit" name="crear_cita" value="Solicitar Cita">
                </td>
            </tr>
        </table>
    </form>

    <!-- Listado de citas -->
    <table>
        <tr>
            <th colspan="6">Mis Citas</th>
        </tr>
        <?php if(empty($citas)){?>
            <tr>
                <td colspan="6">No tienes citas actualmente.</td>
            </tr>
        <?php }else{?>
            <tr>
                <th>Médico</th>
                <th>Especialidad</th>
                <th>Consulta</th>
                <th>Fecha</th>
                <th>Motivo</th>
                <th>Estado</th>
                <th>Acciones</th>
            </tr>
            <?php foreach($citas as $c): ?>
                <tr>
                    <td><?= $c['nombre_medico'] ?></td>
                    <td><?= $c['especialidad'] ?></td>
                    <td><?= $c['consulta'] ?></td>
                    <td><?= $c['fecha'] ?></td>
                    <td><?= $c['nmotivo'] ?></td>
                    <td><?= $c['estado'] ?></td>
                    <td>
                        <?php if($c->activa > 0): ?>
                            <form method="post" action="">
                                <button type="submit" name="cambiar_estado" value="">Atender</button>
                                <button type="submit" name="cancelar" value="">Cancelar</button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach;?>
        <?php } ?>
    </table>
</body>

</html>