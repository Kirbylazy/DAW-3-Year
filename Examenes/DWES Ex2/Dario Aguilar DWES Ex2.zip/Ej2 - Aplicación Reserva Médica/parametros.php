<?php
// Parámetros de conexión a la base de datos
define('DB_HOST', 'localhost');
define('DB_NAME', 'sistema_citas');
define('DB_USER', 'root');
define('DB_PASS', '');

?>