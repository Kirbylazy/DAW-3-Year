<?php

// Función para generar el nombre de archivo específico para el cliente
function obtenerArchivoCliente($id_cliente): string {

    $archivo = $id_cliente . '.txt';

    return $archivo;
}
/*@param id_cliente tenemos que añadr el id del cliente
* @return Nos devuelve todos los paquetes guaradados en nuesto archivo
*/
// Función para leer paquetes de un cliente específico
function leerPaquetes($id_cliente): array {

    $archivo = $id_cliente . '.txt';
    
    if(!file_exists($archivo)){

        return [];
    }

    $datos = file_get_contents($archivo);

    if (empty($datos)){

        return [];
    }

    $paquetes = unserialize($datos);

    return $paquetes;

}
/*@param id_cliente tenemos que añadr el id del cliente
* @param paquetes: tenemos que añadir los paquetes
*/
// Función para guardar todos los paquetes de un cliente
function guardarPaquetes($id_cliente, $paquetes): void {
    
        $archivo = $id_cliente . ".txt";
    
        file_put_contents($archivo, serialize($paquetes));
    
}
/*@param id_cliente tenemos que añadr el id del cliente
* @param paquete tenemos que añadr el paquete a ñadir
*/
// Función para añadir un nuevo paquete
function anadirPaquete($id_cliente, $paquete): void {
    
        $paquetes = leerPaquetes($id_cliente);
        $paquetes[] = $paquete;
        guardarPaquetes($id_cliente, $paquetes);
    
}
/*@param paquetes los paquetes a calcular
* @return nos devuleve el total de los costes
*/
// Función para calcular el coste total de los paquetes de un cliente
function calcularCosteTotal($paquetes): float {

    $total = 0;

    foreach ($paquetes as $p) {
        
        $total += $p->calcularCoste();
    }

    return $total;
}

// Función para generar un ID único para un nuevo paquete (NO TOCAR)
function generarIdPaquete(): string
{
    return uniqid('PKG_');
}
