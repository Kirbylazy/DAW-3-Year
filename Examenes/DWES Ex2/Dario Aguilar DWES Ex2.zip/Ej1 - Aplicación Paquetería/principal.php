<?php
include_once('clases.php');
include_once('funciones.php');

// Verificar si la sesión está activa y renovar cookie. Si no hay cookie vuelve a index.
if(!isset($_COOKIE['id'])){

    header('Location: index.php');
    exit;
}

setcookie('id', $_COOKIE['id'], time() +30);

// Inicializar tipo seleccionado (normal por defecto o el enviado en el formulario) (NO TOCAR)
$tipo_seleccionado = isset($_POST['tipo']) ? $_POST['tipo'] : 'normal';

// Inicializar/crear el archivo del cliente si no existe
$id_cliente = $_COOKIE['id'];

obtenerArchivoCliente($id_cliente);


// Procesar acciones de botones
if($_SERVER['REQUEST_METHOD' == 'POST']){

    // Registrar nuevo paquete
    if(isset($_POST['nuevoPaquete'])){

    // Si se cambia el tipo, solo actualizar la variable (NO TOCAR)
    if (isset($_POST['cambiarTipo'])) {
        $tipo_seleccionado = $_POST['tipo'];
    }

    $id = generarIdPaquete();
    $peso = $_POST['peso'];
    $destino = $_POST['destino'];
    $fecha = $_POST['fecha_envio'];
    $detalle = $_POST['detalle'];

    switch ($tipo_selecionado) {
        case 'normal':
            $p = new Paquete($id, $peso, $destino, $fecha);
            break;
        
        case 'urgente':
            $p = new PaqueteUrgente($id, $peso, $destino, $fecha, $detalle);
            break;

        case 'fragil':
            $p = new PaqueteFragil($id, $peso, $destino, $fecha, $detalle);
            break;
        default:
            echo 'No has selecionado el tipo';
            break;
    }
    }


    // Cerrar sesión
    if(isset($_POST['cerrar'])){

        setcookie('id', $_COOKIE['id'], time()-3600);
        header('Location: index.php');
        exit;
    }


// Obtener paquetes para mostrar

$paquetes = leerPaquetes($id_cliente);

// Calcular coste total



// Establecer etiqueta y valor predeterminado según el tipo seleccionado (NO TOCAR)
$fecha_hoy = date('Y-m-d'); // Fecha actual en formato YYYY-MM-DD

}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Gestión de Paquetería - Panel Principal</title>
    <link rel="stylesheet" href="estilos.css">
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Bienvenido, Cliente <?= $id_cliente ?></h1>
            <form method="post">
                <input type="submit" name="cerrar" value="Cerrar sesión" class="logout">
            </form>
        </div>


        // MOSTRAR MENSAJE, SI HAY
        <div class="message"> CONTENIDO DEL MENSAJE </div>


        <!-- NO TOCAR ESTE FORMULARIO (INICIO)-->
        <h2>Seleccionar Tipo de Paquete</h2>
        <form method="POST"> 
            <div class="form-row">
                <label for="tipo">Tipo de paquete:</label>
                <select name="tipo" id="tipo">
                    <option value="normal" <?php echo ($tipo_seleccionado == 'normal') ? 'selected' : ''; ?>>Normal</option>
                    <option value="urgente" <?php echo ($tipo_seleccionado == 'urgente') ? 'selected' : ''; ?>>Urgente</option>
                    <option value="fragil" <?php echo ($tipo_seleccionado == 'fragil') ? 'selected' : ''; ?>>Frágil</option>
                </select>
                <input type="submit" name="cambiarTipo" value="Seleccionar">
            </div>
        </form>
        <!-- NO TOCAR ESTE FORMULARIO (FIN)-->

        <h2>Registrar Nuevo Paquete <!-- MOSTRAR TIPO DE PAQUETE --> ?></h2>
        <form method="POST">
            <input type="hidden" name="tipo" value="">
            <table border="0">
                <tr>
                    <td><label for="peso">Peso (kg):</label></td>
                    <td><input type="number" id="peso" name="peso" step="0.01" min="0.01" required></td>
                </tr>
                <tr>
                    <td><label for="destino">Destino:</label></td>
                    <td><input type="text" id="destino" name="destino" required></td>
                </tr>
                <tr>
                    <td><label for="fecha_envio">Fecha de envío:</label></td>
                    <td><input type="date" id="fecha_envio" name="fecha_envio" value="<?php echo $fecha_hoy; ?>" required></td>
                </tr>
                <?php if($_POST['tipo'] != 'normal'): ?>
                <tr>
                    <td><label for="detalle"><?php if($_POST['tipo'] == 'urgente'){ echo 'Paquete Urgente';}else{echo 'Paquete Fragil';}?></label></td>
                    <td><input type="text" id="detalle" name="detalle" value="" required></td>
                </tr>
                <?php endif ?>
                <tr>
                    <td colspan="2">
                        <input type="submit" name="nuevoPaquete" value="Registrar Paquete">
                    </td>
                </tr>
            </table>
        </form>

        <h2>Mis Paquetes (Coste total: // COSTE TOTAL €)</h2>

        <?php if(empty($paquetes)){ ?>
            <p>No hay paquetes registrados.</p>
        <?php }elseif(!empty($paquetes)){ ?>
            <table>
                <tr>
                    <th>ID</th>
                    <th>Tipo</th>
                    <th>Peso</th>
                    <th>Destino</th>
                    <th>Fecha Envío</th>
                    <th>Detalles</th>
                    <th>Coste</th>
                </tr>
                <?php foreach($paquetes as $p){ ?>
                    <tr>
                        <td><?= $P->id ?></td>
                        <td><?= 
                            $tipo_seleccionado
                        ?></td>
                        <td><?= $p->peso ?> kg</td>
                        <td><?= $p->destino ?></td>
                        <td><?= $p->fecha_envio ?></td>
                        <td><?= 'detalle' ?></td>
                        <td><?= $p->calcularCoste() ?> €</td>
                    </tr>
                <?php }// FIN DEL BUCLE ?>
            </table>
        <?php }// FINAL DEL IF ?>
    </div>
</body>
</html>