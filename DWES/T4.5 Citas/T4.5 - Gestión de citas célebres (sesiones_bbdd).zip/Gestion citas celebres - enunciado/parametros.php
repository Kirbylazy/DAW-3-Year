<?php

// Configuración de base de datos
define("HOST",'localhost');
define("DB",'citas_celebres');
define("USUARIO",'root');
define("CLAVE",'MANAGER');
