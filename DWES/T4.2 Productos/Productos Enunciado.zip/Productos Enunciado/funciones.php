<?php

require_once('parametros.php');

function conectar()
{

}

function desconectar($conexion)
{

}

function crearProducto($nombre, $descripcion, $precio)
{

}

function obtenerProductos()
{

}

function obtenerProductoPorId($id)
{

}

function actualizarProducto($id, $nombre, $descripcion, $precio)
{

}

function eliminarProducto($id)
{

}
?>