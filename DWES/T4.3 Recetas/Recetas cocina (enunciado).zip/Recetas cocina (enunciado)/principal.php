
<!DOCTYPE html>
<html>

<head>
    <title>Principal</title>
</head>

<body>
    <h1>Recetario</h1>
    <h2>Hola persona ?></h2>
    <form action="" method="POST">
        <!-- Botones para editar y eliminar -->
        <button type="submit" name="listado">Buscar</button>
        <button type="submit" name="misRecetas">Mis recetas</button>
        <button type="submit" name="cerrar">Cerrar sesión</button>
        <br><br>
    </form>

    <TABLE border=1>
        <tr>
            <th>Núm. Receta</th>
            <th>Categoría</th>
            <th>Título</th>
            <th>Puntuación</th>
            <th>Favorito</th>
            <th>Acciones</th>

        </tr>

            <tr>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td>
                    <form action="" method="POST">
                        <button type="submit" name="detalle" value="" ?>>Detalle</button>
                    </form>
                </td>

            </tr>

    </TABLE>
</body>

</html>