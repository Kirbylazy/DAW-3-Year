

<!DOCTYPE html>
<html>

<head>
    <title>Recetario</title>
</head>

<body>
    <h1>Recetario</h1>
    <h2>Registro</h2>
    <form action="" method="POST">
        <label for="email">Nombre:</label>
        <input type="text" name="nombre"><br>
        <label for="email">Email:</label>
        <input type="text" name="email"><br>
        <label for="clave">Contraseña:</label>
        <input type="password" name="clave"><br>
        <label for="clave">Confirmar contraseña:</label>
        <input type="password" name="clave2"><br>
        <button type="submit" name="registrar">Registrar</button>
        <button type="submit" name="volver">Volver</button>
    </form>
    <!-- Aquí informa del mensaje -->

</body>

</html>