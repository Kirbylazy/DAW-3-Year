

<!DOCTYPE html>
<html>

<head>
    <title>Recetario</title>
</head>

<body>
    <h1>Recetario</h1>
    <!-- MOSTRAR LA RECETA QUE MAS VECES SEA FAVORITA -->

    
    <form action="" method="POST">
        <!-- Botones para editar y eliminar -->
        <button type="submit" name="login" >Log in</button>
        <button type="submit" name="registrar" >Registrarse</button>
    </form>
</body>

</html>