
<!DOCTYPE html>
<html>

<head>
    <title>Principal</title>
</head>

<body>
    <h1>Recetario</h1>

    <form action="" method="POST">
        <!-- Botones para editar y eliminar -->
        <button type="submit" name="volver">Volver</button>
        <button type="submit" name="guardar">Guardar</button>
        <br><br>


        <h2>Titulo</h2>
        <TABLE border=1>
            <tr>
                <th>Categoría</th>
                <td> </td>
            </tr>
            <tr>
                <th>Descripción</th>
                <td> </td>
            </tr>
            <tr>
                <th>Pasos</th>
                <td> </td>
            </tr>
            <tr>
                <th>Puntuación</th>
                <td></td>
            </tr>
            <tr>
                <th>Comentario</th>
                <td></td>
            </tr>
            <tr>
                <th>Favorito</th>
                <td></td>
            </tr>
        </TABLE>
    </form>
    <!-- Mensaje -->

</body>

</html>