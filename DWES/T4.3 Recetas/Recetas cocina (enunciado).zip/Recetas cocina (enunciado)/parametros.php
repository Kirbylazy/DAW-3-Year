<?php
    // Declaración de parámetos de conexión. Son constantes.
    define('HOST',      '');
    define('DBNAME',    '');
    define('USERNAME',  '');
    define('PASSWORD',  '');
?>