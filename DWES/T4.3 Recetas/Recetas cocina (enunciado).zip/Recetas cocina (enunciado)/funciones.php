<?php

// PUEDES USAR ESTAS FUNCIONES U OTRAS QUE TU ELIJAS
function conectar()
{

}

function desconectar($conexion)
{

}

function recetafavorita()
{

}

function mostrarReceta($idReceta)
{

}

function obtenerRecetas()
{

}

function obtenerDetalle($id)
{

}

function guardarValoracion($usuario, $receta, $puntuacion, $comentario, $marcarFavorito)
{

}

function esFavorito($usuario, $receta): bool
{

}

function getValoracion($usuario, $receta)
{

}
