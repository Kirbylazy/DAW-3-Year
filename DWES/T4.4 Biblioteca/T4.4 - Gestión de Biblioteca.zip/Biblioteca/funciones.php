<?php 

// Comprobamos si existe el archivo de datos, si no, lo creamos
define("ARCHIVO", "biblioteca.dat");

// Función para guardar materiales en el archivo
function guardarMateriales($materiales):void {
}

// Función para leer materiales desde el archivo
function leerMateriales():array {
}

// Función para añadir materiales
function anadirMaterial($material):void {

}

// Función para cambiar disponibilidad
function cambiarDisponibilidad($identificador):void {

}

// Función para borrar un material
function borrarMaterial($identificador):void {

}

// Gestión de cookies
function registrarVisita($titulo) {

}

// Mensaje de cookies
function obtenerMensaje():string {

}
?>