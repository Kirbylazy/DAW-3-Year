<?php

// Clase base para materiales bibliográficos
class Material {

}

// Clase para libros que hereda de Material
class Libro {

}

// Clase para revistas que hereda de Material
class Revista {

}

?>